﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioBar
{
    public class TipoEmpleado
    {
        public string nombrePuesto { get; set; }
        public string decPuesto { get; set; }
    }
}
